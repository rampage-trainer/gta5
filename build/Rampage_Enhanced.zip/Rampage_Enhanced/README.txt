>--- Overview ----<
Rampage is a Trainer / Modification for Grand Theft Auto V Enhanced Story Mode

>--- How to Install ---<
Extract the .zip file and put the Rampage.asi and RampageFiles into your GTA V Enhanced Directory.
Make sure you have the latest version of Alexander Blades ScriptHookV plugin (ScriptHookV.dll & dinput8.dll (xinput1_4.dll))

If GTA5 Enhanced is installed on your main drive (C:) or you get any issues regarding not being able to save file make sure that your user account and the user group have the correct permissions for the game folder.

-> Make sure to disable BattlEye in Launcher Settings

>--- Troubleshooting ---<
If you encounter any issues while loading such as "Settings.json missing" or "Hotkey.json missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart GTA5 Enhanced.

--- Important Things ---
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the option and enter your new hotkey inside the window.
Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

>--- Controls ---<
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F5
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Number, Decimal, List) =  Right/Left Arrow key or Numpad4  and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5

>--- Terms & Rules ---<
-Online usage of any kind is strictly prohibited.
-You are not allowed to reupload this Trainer anywhere.
-You are not allowed to reverse this Trainer or to modify its code.
-You are not allowed to use resources of this mod without permission
-This Trainer is completly free, so you are not allowed to use this in any commercial way. That means it is forbidden to sell it. (Making YT videos is allowed)
-You are responsible for your own actions.
-This terms may change whenever its necessary

>--- Credits ---<

GTA5 Modding Resources
-> alloc8or Native DB
-> alloc8or for his multiplayer vehicle bypass
-> Thenecromance for his Json Vehicle Loader
-> MAFINS (Menyoo) for xml compatibility


>--- Changelog ---<

1.3E

-> Fixed Bug with Vehicle Lights on XML Loader
-> Fixed issue with saving Selected Text Color
-> Added Toggle Auto Save